document.addEventListener("DOMContentLoaded", function() {

});
