<?php $__env->startSection('contentMain'); ?>
    <div class="flex justify-center mt-10">
        <div class="w-full lg:w-9/12">
            <p class="text-center text-2xl text-gray-600 mb-5">Halaman List Pendaftar</p>
            <div class="flex justify-center my-5">
                <a href="/page-create"
                    class="px-5 py-2 w-36 text-white rounded-lg bg-blue-400 border border-blue-400 hover:bg-white hover:text-black text-center text-lg font-semibold">Registrasi</a>
            </div>

            <div class="flex justify-center">
                <form action="<?php echo e(route('home')); ?>" method="GET" class="inline">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-4 gap-5">
                        <div>
                            <label for="nama_user" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nama
                                Pendaftar</label>
                            <input type="text" id="nama_user" name="nama_user"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                placeholder="Masukan Nama Pendaftar" />
                        </div>


                        <div>
                            <label for="jenis_kelamin"
                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Jenis Kelamin</label>
                            <select id="jenis_kelamin" name="jenis_kelamin"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                                <option selected disabled>Pilih Jenis Kelamin</option>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>

                        <div>
                            <label for="jurusan" class="block mb-2 text-sm font-medium text-gray-900 ">Jurusan
                                Sekolah</label>
                            <select id="jurusan" name="jurusan"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                                <option selected disabled>Pilih Jurusan Sekolah</option>
                                <option value="RPL">RPL</option>
                                <option value="TKJ">TKJ</option>
                                <option value="MM">MM</option>
                            </select>
                        </div>

                        <div class="flex justify-start gap-2 items-end">
                            <button type="submit"
                                class="py-2 px-5 bg-blue-400 border border-blue-400 hover:bg-white text-white hover:text-black rounded-lg">Cari
                                Pendaftar</button>
                            <button type="reset"
                                class="py-2 px-5 w-32 bg-orange-400 border border-orange-400 hover:bg-white text-white hover:text-black rounded-lg">Reset</button>
                        </div>
                    </div>
                </form>
            </div>


            <div class="w-full rounded-lg shadow-lg my-5">
                <table class="min-w-full">
                    <thead>
                        <tr>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider">
                                No.</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider w-1/4">
                                Nama Pendaftar</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider w-1/5">
                                Alamat</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider ">
                                Jenis Kelamin</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider ">
                                No. HP</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider w-1/6">
                                Asal Sekolah</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider ">
                                Jurusan</th>
                            <th
                                class="px-6 py-3 bg-gray-50 text-left text-sm font-semibold leading-4 text-gray-500 uppercase tracking-wider w-1/6">
                                Tanggal Lahir</th>
                            <th class="px-6 py-3 bg-gray-50 text-gray-500 w-1/4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__empty_1 = true; $__currentLoopData = $pendaftars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-blue-100">
                                <td class="px-6 py-4 whitespace-no-wrap">
                                    <?php echo e(($pendaftars->currentPage() - 1) * $pendaftars->perPage() + $loop->index + 1); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->nm_pendaftar); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->alamat); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->jenis_kelamin); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->no_hp); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->asal_sekolah); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e($data->jurusan); ?></td>
                                <td class="px-6 py-4 whitespace-no-wrap"><?php echo e(date('d/m/Y', strtotime($data->tgl_lahir))); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-no-wrap flex justify-center gap-2 items-center">
                                    <a href="<?php echo e(route('account.edit', ['id_pendaftar' => $data->id_pendaftar])); ?>"
                                        class="text-white font-semibold rounded-lg py-2 px-4 bg-yellow-300 border border-yellow-300 hover:bg-white hover:text-black w-20 text-center">Edit</a>
                                    <form action="<?php echo e(route('account.delete', ['id_pendaftar' => $data->id_pendaftar])); ?>"
                                        method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')"
                                            class="text-white font-semibold rounded-lg py-2 px-4 bg-red-400 border border-red-400 hover:bg-white hover:text-black w-20 text-center">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="px-6 py-4 text-center text-gray-500">
                                    Data tidak tersedia
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
            <div class="my-5">
                <?php echo e($pendaftars->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sertifikasi-lsp\projek jwd\temp\resources\views/list-pendaftar.blade.php ENDPATH**/ ?>