<?php $__env->startSection('content'); ?>
    <div class="">
        <nav class="fixed top-0 w-full z-50  border-gray-200 bg-custom-yellow  py-0 lg:py-1">
            <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4 md:p-2">
                <button data-collapse-toggle="navbar-user" type="button"
                    class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 "
                    aria-controls="navbar-user" aria-expanded="false">
                    <span class="sr-only">Open main menu</span>
                    <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 17 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M1 1h15M1 7h15M1 13h15" />
                    </svg>
                </button>
                <a href="<?php echo e(route('home')); ?>" class="flex items-center space-x-3 rtl:space-x-reverse">
                    <img src="<?php echo e(asset('img/logo/logo-ppdb.png')); ?>" class="h-14" alt="Flowbite Logo" />
                </a>

                <div class="items-center bg-white rounded-lg md:bg-custom-yellow justify-between hidden w-full md:flex md:w-auto md:order-1"
                    id="navbar-user">
                    <ul
                        class="flex flex-col font-medium p-4 md:p-0 lg:mt-2 border rounded-lg md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 ">
                        <li>
                            <a href="<?php echo e(url('/home')); ?>"
                                class="block py-2 px-3 text-custom-midnight rounded hover:text-white hover:bg-custom-yellow md:bg-transparent md:text-custom-bg-custom-white md:hover:text-white md:p-0 <?php echo e(request()->is('/') ? 'text-white bg-custom-yellow' : ''); ?>"
                                aria-current="page">Home</a>
                        </li>

                        
                    </ul>
                </div>

                <div class="flex items-center md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('account.logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="py-2 px-5 bg-red-600 border border-red-600 hover:bg-white hover:text-black rounded-lg font-semibold text-white">Logout</button>
                        </form>
                    <?php endif; ?>
                </div>

            </div>
        </nav>

        <div class="pt-16 lg:pt-16 min-h-screen"><?php echo $__env->yieldContent('contentMain'); ?></div>





        <!-- Your existing HTML content here -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sertifikasi-lsp\projek jwd\temp\resources\views/layouts/main.blade.php ENDPATH**/ ?>