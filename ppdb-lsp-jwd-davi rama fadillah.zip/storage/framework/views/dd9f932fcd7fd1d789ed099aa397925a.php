
<?php $__env->startSection('contentMain'); ?>
    <div class="relative p-4 w-full max-h-full flex justify-center">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-center p-4 md:p-5 border-b border-custom-purple rounded-t ">
                <h3 class="text-lg text-center font-semibold text-gray-900 dark:text-white">
                    Edit Akun Peserta
                </h3>

            </div>
            <!-- Modal body -->
            <form id="register-form" action="<?php echo e(route('account.update', ['id_pendaftar' => $pendaftar->id_pendaftar])); ?>"
                method="POST" class="p-4 md:p-5" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="grid gap-4 mb-4 grid-cols-2">
                    <div class="col-span-2">
                        <label for="nm_pendaftar" class="block mb-2 text-sm font-medium text-gray-900 ">Nama
                            Lengkap</label>
                        <input type="text" name="nm_pendaftar" id="nm_pendaftar" required
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                            placeholder="Masukan Nama Peserta" required value="<?php echo e($pendaftar->nm_pendaftar); ?>">
                    </div>

                    <div class="col-span-2">
                        <label for="alamat" class="block mb-2 text-sm font-medium text-gray-900 ">Alamat</label>
                        <textarea required name="alamat" id="alamat" cols="55" rows="2"
                            class="rounded-lg text-sm focus:ring-custom-purple focus:border-custom-purple bg-gray-50 border border-gray-300"
                            placeholder="Masukan Alamat Peserta"><?php echo e($pendaftar->alamat); ?></textarea>
                    </div>

                    <div class="col-span-2">
                        <label for="jenis_kelamin" class="block mb-2 text-sm font-medium text-gray-900 ">Jenis
                            Kelamin</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" required
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                            <option disabled>Pilih Jenis Kelamin</option>
                            <option value="Laki-laki" <?php if($pendaftar->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php if($pendaftar->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                        </select>
                    </div>

                    <div class="col-span-2">
                        <label for="no_hp" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nomor
                            Handphone</label>
                        <input type="number" name="no_hp" id="no_hp"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                            value="<?php echo e($pendaftar->no_hp); ?>" placeholder="Masukan Nomor Handphone Peserta" required
                            title="Hanya masukkan angka">
                    </div>

                    <div class="col-span-2">
                        <label for="asal_sekolah" class="block mb-2 text-sm font-medium text-gray-900 ">Asal Sekolah</label>
                        <input type="text" name="asal_sekolah" id="asal_sekolah" required
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                            placeholder="Masukan Nama Peserta" required value="<?php echo e($pendaftar->asal_sekolah); ?>">
                    </div>

                    <div class="col-span-2">
                        <label for="jurusan" class="block mb-2 text-sm font-medium text-gray-900 ">Jurusan Sekolah</label>
                        <select id="jurusan" name="jurusan" required
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 ">
                            <option disabled>Pilih Jurusan Sekolah</option>
                            <option value="RPL" <?php if($pendaftar->jurusan == 'RPL'): ?> selected <?php endif; ?>>RPL</option>
                            <option value="TKJ" <?php if($pendaftar->jurusan == 'TKJ'): ?> selected <?php endif; ?>>TKJ</option>
                            <option value="MM" <?php if($pendaftar->jurusan == 'MM'): ?> selected <?php endif; ?>>MM</option>
                        </select>
                    </div>

                    <div class="col-span-2">
                        <label for="tgl_lahir" class="block mb-2 text-sm font-medium text-gray-900 ">Tanggal Lahir</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                                </svg>
                            </div>
                            <input datepicker datepicker-format="d/m/y" type="text" name="tgl_lahir"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 "
                                placeholder="Pilih Tanggal Lahir Peserta"
                                value="<?php echo e($pendaftar->tgl_lahir ? date('d/m/Y', strtotime($pendaftar->tgl_lahir)) : ''); ?>">
                        </div>
                    </div>
                </div>

                <div class="col-span-2">
                    <label for="nisn" class="block mb-2 text-sm font-medium text-gray-900 ">NISN</label>
                    <input type="number" name="nisn" id="nisn" required
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                        placeholder="Masukan Nama Peserta" required value="<?php echo e($pendaftar->nisn); ?>">
                </div>

                <button type="submit"
                    class="my-5 text-white w-full inline-flex items-center justify-center bg-custom-purple hover:bg-custom-midnight focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5">
                    <span class="text-center">Edit Data Pendaftar</span>
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sertifikasi-lsp\projek jwd\temp\resources\views/form_edit.blade.php ENDPATH**/ ?>