<?php $__env->startSection('contentMain'); ?>
    <div class="flex justify-center items-center pt-10">
        <div class="relative p-4 w-full max-w-md max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div
                    class="flex items-center justify-between p-4 md:p-5 border-b border-custom-purple rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Login Akun Admin
                    </h3>
                </div>
                <!-- Modal body -->
                <div class="p-4 md:p-5">
                    <form class="space-y-4" method="POST" action="<?php echo e(route('account.login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="email_user" class="block mb-2 text-sm font-medium text-gray-900 ">Email</label>
                            <input type="email_user" name="email_user" id="email_user"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                                placeholder="Masukan Email Anda" required />
                        </div>
                        <div>
                            <label for="password" class="block mb-2 text-sm font-medium text-gray-900 ">
                                password</label>
                            <input type="password" name="password" id="password" placeholder="••••••••"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-custom-purple focus:border-custom-purple block w-full p-2.5"
                                required />
                        </div>


                        <button type="submit"
                            class="w-full text-white bg-custom-purple hover:bg-custom-maroon focus:ring-4 focus:outline-none focus:ring-custom-purple font-medium rounded-lg text-sm px-5 py-2.5 text-center">Login
                        </button>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sertifikasi-lsp\projek jwd\temp\resources\views/index.blade.php ENDPATH**/ ?>