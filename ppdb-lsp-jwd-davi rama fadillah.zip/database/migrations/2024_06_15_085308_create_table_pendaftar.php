<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pendaftar', function (Blueprint $table) {
            $table->id('id_pendaftar');
            $table->string('nm_pendaftar');
            $table->string('alamat');
            $table->enum('jenis_kelamin', ['Laki-laki', 'Perempuan']);
            $table->string('no_hp');
            $table->string('asal_sekolah');
            $table->enum('jurusan', ['RPL', 'TKJ', 'MM']);
            $table->date('tgl_lahir');
            $table->string('nisn')->unique();
            $table->timestamps();
        });

        DB::table('pendaftar')->insert([
            [
                'nm_pendaftar' => 'Dena Arfiza',
                'alamat' => 'Jl. Tukang No. 123',
                'jenis_kelamin' => 'Laki-laki',
                'no_hp' => '081243456789',
                'asal_sekolah' => 'SMK 51 Jakarta',
                'jurusan' => 'RPL',
                'tgl_lahir' => '2000-01-01',
                'nisn' => '123456789012',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nm_pendaftar' => 'Rina Haryani',
                'alamat' => 'Jl. Rindam No. 456',
                'jenis_kelamin' => 'Perempuan',
                'no_hp' => '081232456788',
                'asal_sekolah' => 'SMK Tubagus',
                'jurusan' => 'TKJ',
                'tgl_lahir' => '2000-02-02',
                'nisn' => '1234567891',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nm_pendaftar' => 'Dinda Septiani',
                'alamat' => 'Jl. Guru No. 16',
                'jenis_kelamin' => 'Perempuan',
                'no_hp' => '0812314567128',
                'asal_sekolah' => 'SMK Tadika Mesra',
                'jurusan' => 'MM',
                'tgl_lahir' => '2000-12-02',
                'nisn' => '12345678110',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nm_pendaftar' => 'Dena Rindang',
                'alamat' => 'Jl. Tukang No. 13',
                'jenis_kelamin' => 'Laki-laki',
                'no_hp' => '081235456789',
                'asal_sekolah' => 'SMK 51 Jakarta',
                'jurusan' => 'RPL',
                'tgl_lahir' => '2000-11-01',
                'nisn' => '1234597890',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nm_pendaftar' => 'Rina Hartanto',
                'alamat' => 'Jl. Rindam No. 6',
                'jenis_kelamin' => 'Perempuan',
                'no_hp' => '081423456788',
                'asal_sekolah' => 'SMK Tubagus',
                'jurusan' => 'TKJ',
                'tgl_lahir' => '2000-02-023',
                'nisn' => '1231567891',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nm_pendaftar' => 'Dinda Ariani',
                'alamat' => 'Jl. Guru No. 1',
                'jenis_kelamin' => 'Perempuan',
                'no_hp' => '081234567129',
                'asal_sekolah' => 'SMK Tadika Mesra',
                'jurusan' => 'MM',
                'tgl_lahir' => '2000-12-02',
                'nisn' => '123456129110',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }



    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pendaftar');
    }
};
