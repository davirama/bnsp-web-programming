<?php

use App\Http\Controllers\AccountUserController;
use App\Http\Controllers\PendaftarController;
use App\Http\Controllers\BadgeUserController;
use App\Http\Controllers\ForumCategoriesController;
use App\Http\Controllers\Quiz2Controller;
use App\Http\Controllers\ReportForumController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RankGamifikasiController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\JenisPakaianController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\ArtikelController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DashboardAdmin;
use App\Http\Controllers\DashboardAdminController;
use App\Http\Controllers\DashboardPelangganController;
use App\Http\Controllers\PenjualanController;
use App\Http\Controllers\PengajuanController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\ForumResponseController;
use App\Http\Controllers\inspeksiController;
use App\Http\Controllers\InteraksiAvatarController;
use App\Http\Controllers\Quiz1Controller;
use App\Http\Middleware\AdminOnly;
use App\Http\Middleware\AuthenticateUser;
use App\Http\Middleware\PelangganOnly;
use App\Http\Controllers\ReportForumResponseController;
use App\Mail\SendEmail;
use App\Models\AccountUser;
use App\Http\Middleware\InspektorOnly;
use App\Models\ReportForum;
use Illuminate\Support\Facades\Mail;

Route::view('/', 'index')->name('index');
Route::post('/login', [AccountUserController::class, 'login'])->name('account.login');
Route::post('/logout', [AccountUserController::class, 'logout'])->name('account.logout');



// ROUTES UNTUK PAGE YANG BUTUH MIDDLEWARE USER HARUS LOGIN KELOMPOKKAN DIBAWAH SINI
Route::middleware([AuthenticateUser::class])->group(function () {
  Route::get('/home', [PendaftarController::class, 'index'])->name('home');
  Route::view('/page-create', 'form_registrasi');
  Route::post('/registrasi', [PendaftarController::class, 'create'])->name('account.create');
  Route::get('/edit/{id_pendaftar}', [PendaftarController::class, 'edit'])->name('account.edit');
  Route::put('/update/{id_pendaftar}', [PendaftarController::class, 'update'])->name('account.update');

  Route::delete('/pendaftar/{id_pendaftar}', [PendaftarController::class, 'delete'])->name('account.delete');
});
// ROUTES UNTUK PAGE YANG BUTUH MIDDLEWARE USER HARUS LOGIN KELOMPOKKAN DIATAS SINI
