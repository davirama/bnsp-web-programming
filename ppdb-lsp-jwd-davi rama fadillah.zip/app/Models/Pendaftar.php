<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pendaftar extends Model
{
    protected $table = 'pendaftar';

    protected $primaryKey = 'id_pendaftar';

    protected $fillable = [
        'nm_pendaftar',
        'alamat',
        'jenis_kelamin',
        'no_hp',
        'asal_sekolah',
        'jurusan',
        'tgl_lahir',
        'nisn',
    ];
}
