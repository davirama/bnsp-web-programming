<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable as AuthenticatableTrait;

class AccountUser extends Model implements Authenticatable
{
    use AuthenticatableTrait;
    protected $table = 'account_user';

    protected $primaryKey = 'user_id';

    protected $fillable = [
        'user_id_attr',
        'role_user',
        'nama_user',
        'email_user',
        'password',
    ];
}
