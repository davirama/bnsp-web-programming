<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Pendaftar;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PendaftarController
{

    public function index(Request $request)
    {
        // Ambil data pencarian dari formulir
        $nama_user = $request->input('nama_user');
        $jenis_kelamin = $request->input('jenis_kelamin');
        $jurusan = $request->input('jurusan');

        // Query untuk menyaring data Pendaftar
        $query = Pendaftar::query();

        // Tambahkan kriteria pencarian ke dalam query
        if ($nama_user) {
            $query->where('nm_pendaftar', 'like', '%' . $nama_user . '%');
        }

        if ($jenis_kelamin) {
            $query->where('jenis_kelamin', $jenis_kelamin);
        }

        if ($jurusan) {
            $query->where('jurusan', $jurusan);
        }

        // Lakukan pagination pada hasil query
        $pendaftars = $query->paginate(3); // Misalnya, menggunakan 10 item per halaman

        // Kembalikan hasil pencarian ke tampilan
        return view('list-pendaftar', compact('pendaftars'));
    }


    public function create(Request $request)
    {
        // Validasi request
        $request->validate([
            'nm_pendaftar' => 'required|string|max:255',
            'alamat' => 'required|string',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'no_hp' => 'required|string|max:20',
            'asal_sekolah' => 'required|string|max:255',
            'jurusan' => 'required|in:RPL,TKJ,MM',
            'tgl_lahir' => 'required',
            'nisn' => [
                'required',
                'string',
                'max:10',
            ],
        ]);

        // Buat pendaftar baru
        $pendaftar = new Pendaftar();
        $pendaftar->nm_pendaftar = $request->nm_pendaftar;
        $pendaftar->alamat = $request->alamat;
        $pendaftar->jenis_kelamin = $request->jenis_kelamin;
        $pendaftar->no_hp = $request->no_hp;
        $pendaftar->asal_sekolah = $request->asal_sekolah;
        $pendaftar->jurusan = $request->jurusan;
        $pendaftar->tgl_lahir = Carbon::createFromFormat('d/m/Y', $request->tgl_lahir)->format('Y-m-d');
        $pendaftar->nisn = $request->nisn;

        // Simpan data pendaftar
        $pendaftar->save();

        // Redirect atau tampilkan pesan sukses
        return redirect()->route('home')->with('success', 'Data pendaftar berhasil dibuat.');
    }

    public function edit($id_pendaftar)
    {
        $pendaftar = Pendaftar::where('id_pendaftar', $id_pendaftar)->first();
        // dd($pendaftar);
        return view('form_edit', compact('pendaftar'));
    }

    public function update(Request $request, $id_pendaftar)
    {
        // Validasi request
        $request->validate([
            'nm_pendaftar' => 'required|string|max:255',
            'alamat' => 'required|string',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'no_hp' => 'required|string|max:20',
            'asal_sekolah' => 'required|string|max:255',
            'jurusan' => 'required|in:RPL,TKJ,MM',
            'tgl_lahir' => 'required',
            'nisn' => [
                'required',
                'string',
                'max:10',
            ],
        ]);

        // Ambil data pendaftar berdasarkan ID
        $pendaftar = Pendaftar::findOrFail($id_pendaftar);

        // Perbarui data pendaftar
        $pendaftar->nm_pendaftar = $request->nm_pendaftar;
        $pendaftar->alamat = $request->alamat;
        $pendaftar->jenis_kelamin = $request->jenis_kelamin;
        $pendaftar->no_hp = $request->no_hp;
        $pendaftar->asal_sekolah = $request->asal_sekolah;
        $pendaftar->jurusan = $request->jurusan;
        $pendaftar->tgl_lahir = Carbon::createFromFormat('d/m/Y', $request->tgl_lahir)->format('Y-m-d');
        $pendaftar->nisn = $request->nisn;
        // Simpan perubahan
        $pendaftar->save();

        // Redirect atau tampilkan pesan sukses
        return redirect()->route('home')->with('success', 'Data pendaftar berhasil diperbarui.');
    }

    public function delete($id_pendaftar)
    {
        // Cari data pendaftar berdasarkan ID
        $pendaftar = Pendaftar::findOrFail($id_pendaftar);

        // Hapus data pendaftar
        $pendaftar->delete();

        // Redirect atau tampilkan pesan sukses
        return redirect()->route('home')->with('success', 'Data pendaftar berhasil dihapus.');
    }
}
