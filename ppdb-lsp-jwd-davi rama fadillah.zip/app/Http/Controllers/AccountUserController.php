<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\ConfirmAccountMail;
use App\Models\Province;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\AccountUser;
use App\Models\City;
use App\Models\RankGamifikasi;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

use App\Mail\DemoMail;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail as FacadesMail;
use Illuminate\Support\Facades\Storage;

class AccountUserController
{

    public function login(Request $request)
    {
        $request->validate(['email_user' => 'required|string', 'password' => 'required|string']);

        if (Auth::attempt(['email_user' => $request->email_user, 'password' => $request->password])) {
            $user = Auth::user();
            return redirect()->route('home')->with('success', 'Berhasil Login');
        }
        Auth::logout();
        return redirect()->back()->withErrors(['email_user' => 'Gagal login, Email atau password Anda salah.']);
    }

    public function logout()
    {
        Auth::logout();

        // Redirect to the desired location after logout, for example, the home page
        return redirect()->route('index')->with('success', 'Berhasil Logout');
    }
}
